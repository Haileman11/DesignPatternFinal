﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        
        Swimmer playerGroup1 = new Swimmer();
        

        private int numberOfSwimmers;
        private const int ARRAY_SIZE = 10;
        private double[] time = new double[ARRAY_SIZE];
        private int[] age = new int[ARRAY_SIZE];
        string[] gender = new string[ARRAY_SIZE];
        string[] name = new string[ARRAY_SIZE];
        string[] agegroup = new string[ARRAY_SIZE];
        
      
      

        void swapArrayValues(int i, int c)
        {
            int tempId = age[i];
            string tempName = name[i];
            string tempAgeGroup = agegroup[i];
            double tempTime = time[i];
            string tempGender = gender[i];

            age[i] = age[c];
            name[i] = name[c];
            agegroup[i] = agegroup[c];
            time[i] = time[c];
            gender[i] = gender[c];

            age[c] = tempId;
            name[c] = tempName;
            agegroup[c] = tempAgeGroup;
            time[c] = tempTime;
            gender[c] = tempGender;


        }

       
        void displayArrays()

        {
            
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            listBox4.Items.Clear();
            listBox5.Items.Clear();
           

            for(int i=0;i< numberOfSwimmers; i++)
            {
                playerGroup1.Name = name[i];
                playerGroup1.Age = age[i];
                playerGroup1.Time = time[i];
                playerGroup1.Gender = gender[i];
                playerGroup1.AgeGroup = agegroup[i];

                listBox1.Items.Add(playerGroup1.Name);
                listBox2.Items.Add(playerGroup1.Age.ToString());
                listBox3.Items.Add(playerGroup1.Time.ToString());
                listBox4.Items.Add(playerGroup1.Gender);
                listBox5.Items.Add(playerGroup1.AgeGroup);

                
            }
        }
        void sortedDisplayArrays()

        {

            listBox6.Items.Clear();
            listBox7.Items.Clear();
            listBox8.Items.Clear();
            listBox9.Items.Clear();
            listBox10.Items.Clear();


            for (int i = 0; i < numberOfSwimmers; i++)
            {
                playerGroup1.Name = name[i];
                playerGroup1.Age = age[i];
                playerGroup1.Time = time[i];
                playerGroup1.Gender = gender[i];
                playerGroup1.AgeGroup = agegroup[i];

                listBox6.Items.Add(playerGroup1.Name);
                listBox7.Items.Add(playerGroup1.Age.ToString());
                listBox8.Items.Add(playerGroup1.Time.ToString());
                listBox9.Items.Add(playerGroup1.Gender);
                listBox10.Items.Add(playerGroup1.AgeGroup);


            }
        }

        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttton6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bunifuImageButton2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            int i = 0;
            try
            {
                FileStream fs = new FileStream(@"C:\Users\Abraham\Desktop\Data.txt", FileMode.Open);
                StreamReader sr = new StreamReader(fs);

                while (sr.Peek() != -1)
                {
                    if (numberOfSwimmers < name.Length)
                    {
                        name[numberOfSwimmers] = sr.ReadLine();
                        age[numberOfSwimmers] = Convert.ToInt32(sr.ReadLine());
                        time[numberOfSwimmers] = Convert.ToDouble(sr.ReadLine());
                        gender[numberOfSwimmers] = sr.ReadLine();
                        agegroup[numberOfSwimmers] = sr.ReadLine();
                        numberOfSwimmers++;

                    }
                    else
                    {
                        MessageBox.Show("Error: Array size has been Exceeded.", "Array Size Exceed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        break;
                    }
                }
                fs.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Array size has been Exceeded.", "Array Size Exceed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            displayArrays();
            
            button5.Visible = false;

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (numberOfSwimmers > 0)
            {
                for (int i = 0; i < numberOfSwimmers - 1; i++)
                {
                    for (int c = i + 1; c < numberOfSwimmers; c++)
                    {
                        if (string.Compare(agegroup[c], agegroup[i]) < 0)
                        {
                            swapArrayValues(i, c);
                        }


                    }

                }

                sortedDisplayArrays();
            }
            else
            {
                MessageBox.Show("Arrays were not loaded yet");
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (numberOfSwimmers > 0)
            {
                for (int i = 0; i < numberOfSwimmers - 1; i++)
                {
                    for (int c = i + 1; c < numberOfSwimmers; c++)
                    {
                        if (age[c] < age[i])
                        {
                            swapArrayValues(i, c);
                        }


                    }

                }

                sortedDisplayArrays();
            }
            else
            {
                MessageBox.Show("Arrays were not loaded yet");
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            if (numberOfSwimmers > 0)
            {
                for (int i = 0; i < numberOfSwimmers - 1; i++)
                {
                    for (int c = i + 1; c < numberOfSwimmers; c++)
                    {
                        if (string.Compare(gender[c], gender[i]) < 0)
                        {
                            swapArrayValues(i, c);
                        }


                    }

                }

                sortedDisplayArrays();
            }
            else
            {
                MessageBox.Show("Arrays were not loaded yet");
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (numberOfSwimmers > 0)
            {
                for (int i = 0; i < numberOfSwimmers - 1; i++)
                {
                    for (int c = i + 1; c < numberOfSwimmers; c++)
                    {
                        if (time[c] < time[i])
                        {
                            swapArrayValues(i, c);
                        }


                    }

                }

                sortedDisplayArrays();
            }
            else
            {
                MessageBox.Show("Arrays were not loaded yet");
            }
        }
    }

    public abstract class SwimmerDetails
    {
        string m_name;
        int m_age;
        double m_time;
        string m_gender;
        string m_agegroup;

        public string Name
        {
            get
            {
                return m_name;
            }
            set
            {
                m_name = value;
            }
        }
        public int Age
        {
            get
            {
                return m_age;
            }
            set
            {
                m_age = value;
            }
        }
        public double Time
        {
            get
            {
                return m_time;
            }
            set
            {
                m_time = value;
            }
        }
        public string Gender
        {
            get
            {
                return m_gender;
            }
            set
            {
                m_gender = value;
            }
        }
        public string AgeGroup
        {
            get
            {
                return m_agegroup;
            }
            set
            {
                m_agegroup = value;
            }
        }

        public abstract SwimmerDetails Clone();
    }

    public class Swimmer : SwimmerDetails
    {
        public override SwimmerDetails Clone()
        {
            Swimmer cloned = this.MemberwiseClone() as Swimmer;
            cloned.Name = this.Name;
            cloned.Age = this.Age;
            cloned.Time = this.Time;
            cloned.Gender = this.Gender;
            cloned.AgeGroup = this.AgeGroup;

            return cloned as Swimmer;

        }
    }
}
